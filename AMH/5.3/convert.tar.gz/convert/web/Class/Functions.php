<?php

/************************************************
 * AMH 5.3
 * amh.sh 
 * @param Object Functions 面板常用函数类
 * @copyright AMH & amh.sh
 * @license APL (http://amh.sh/apl.htm) V1.0
 * Update:2016-05-01
 * 
 */

class Functions
{
	// 过滤结果数据
	function trim_result($result, $slice = 6)
	{
		$result = trim($result);
		$result_arr = explode("\n", $result);
		$result_arr = array_slice($result_arr, $slice);
		$result = implode("\n", $result_arr);
		Return $result;
	}

	// 命令过滤
	function trim_cmd($cmd)
	{
		$cmd = str_replace(array(';', '&', '|', '`'), ' ', trim($cmd));
		$cmd = str_replace(array('#'), array('\\\\#'), trim($cmd));
		$cmd = preg_replace("/[ ]+/", " ", $cmd);
		Return $cmd;
	}
	
	// 分页页码
	function page ($name, $total_num, $total_page, $page, $set_url = null)
	{
		$uri = explode('?', $_SERVER['REQUEST_URI']);
		$url = _Host . $uri[0] . '?';

		if (!empty($set_url))
			$url .= $set_url;
		else
			$url .= preg_replace("/[\&]{0,}page\=[0-9]+/i", '', $uri[1]);
		
		$data = NULL;
		$url_model = '<a id="$id" href="$url&page=$page">$txt</a>';
		$replace_name = array('$url', '$page', '$name', '$txt', '$id');

		if($page-3>0)
		{
			$start=$page-3;
			if($page+3<$total_page)	
				$end=$page+3;	
			else
			{
				if($total_page-6>0)
					$start=$total_page-6;
				else
					$start=1;
				$end=$total_page;
			}
		}
		else
		{
			$start=1;
			if($total_page<7)
				$end=$total_page;
			else
				$end=7;
		}		

		if($page>1)
			$data .= str_replace($replace_name, array($url, $page-1, $name, '<', ''), $url_model);

		if($start!=1)
			$data .= str_replace($replace_name, array($url, '1', $name, '1', ''), $url_model) . ' ...';

		for($i=$start;$i<=$end;$i++)
		{
			if ($i==$page)
				$data .= '' . str_replace($replace_name, array($url, $i, $name, $i, 'page_now'), $url_model) ;
			else
				$data .= '' . str_replace($replace_name, array($url, $i, $name, $i, ''), $url_model);
		}

		if($end!=$total_page)
			$data .= ' ... ' . str_replace($replace_name, array($url, $total_page, $name, $total_page, ''), $url_model) ;
		if($total_page > $page)
			$data .= '' . str_replace($replace_name, array($url, $page+1, $name, '>', ''), $url_model) ;

		Return str_replace('?&', '?', $data);
	}
	
	
	// 面板检查登录
	static function CheckLogin()
	{
		// 未登录验证
		if (!isset($_SESSION['amh_user_name']) || empty($_SESSION['amh_user_name']))
		{
			if (isset($_GET['tag'])) // ajax
				exit();

			unset($_SESSION['LAST_REQUEST_URI']);
			if($_GET['login'] != 'login')
				$_SESSION['LAST_REQUEST_URI'] = $_SERVER['REQUEST_URI'];
			header('location:./index.php?c=index&a=login');
			exit();
		}

		// 登录成功后取得最新配置
		global $Amysql;
		$CM = $Amysql -> AmysqlProcess -> AmysqlController -> _model('configs');
		$_SESSION['amh_config'] =  $CM -> get_amh_config();
		$_SESSION['amh_module_menu'] = $CM -> get_module_menu();

		// CSRF防范
		if(($_SESSION['amh_config']['OpenCSRF']['config_value'] == 'On') && (!isset($_REQUEST['amh_token']) || $_REQUEST['amh_token'] != $_SESSION['amh_token']) )
		{
			$_SESSION['CSRF_Url'] = trim(_Http, '/') . $_SERVER['REQUEST_URI'];
			header('location:./index.php?c=index&a=index_csrf');
			exit();
		}

		// 授权判断
		/*if (isset($_GET['c']) && $_GET['c'] != 'config')
		{
			if (empty($_SESSION['amh_config']['WebKeyPass']['config_value']) || $_SESSION['amh_config']['WebKeyTime']['config_value'] < time())
			{
				if (isset($_GET['tag'])) // ajax
					exit();

				if (empty($_SESSION['amh_config']['WebKeyPass']['config_value']))
					$_SESSION['Klogin'] = 1;
				else
					$_SESSION['Ktime'] = 1;

				$amh_token = isset($_GET['amh_token']) ? "&amh_token={$_GET['amh_token']}" : '';
				header("location:./index.php?c=config{$amh_token}");
				exit();
			}
		}*/
		
	}

	// 数据加密传输避免监听
	function sys_auth($string, $operation = 'ENCODE', $key = 'amh_key', $expiry = 0) 
	{
		if($operation == 'ENCODE')
			$string = urlencode( $string );

		$key_length = 4;
		$key = md5($key != '' ? $key : 'amh_key');
		$fixedkey = md5($key);
		$egiskeys = md5(substr($fixedkey, 16, 16));
		$runtokey = $key_length ? ($operation == 'ENCODE' ? substr(md5(microtime(true)), -$key_length) : substr($string, 0, $key_length)) : '';
		$keys = md5(substr($runtokey, 0, 16) . substr($fixedkey, 0, 16) . substr($runtokey, 16) . substr($fixedkey, 16));
		$string = $operation == 'ENCODE' ? sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($string.$egiskeys), 0, 16) . $string : base64_decode(substr($string, $key_length));

		$i = 0; $result = '';
		$string_length = strlen($string);
		for ($i = 0; $i < $string_length; $i++){
			$result .= chr(ord($string{$i}) ^ ord($keys{$i % 32}));
		}
		if($operation == 'ENCODE') {
			return  $runtokey . base64_encode($result) ;
		} else {
			if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$egiskeys), 0, 16)) {
				return urldecode( substr($result, 26));
			} else {
				return '';
			}
		}
	}

	// 统计时间
	static function CountTime($time) 
	{
		$TimeList = array(
			array('秒钟',1,60), array('分钟',60,3600), array('小时',3600,86400), 
			array('天',86400,2592000), array('月',2592000,31104000), array('年',31104000, NULL)
		);

		foreach ($TimeList as $val)
		{
			if($time >= $val[1] && ($time < $val[2] || $val[2] === NULL)) 
				Return array(round($time / $val[1], 1) , $val[0]);
		}
	}

}

?>