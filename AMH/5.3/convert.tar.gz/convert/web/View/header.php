<?php 
	!defined('_Amysql') && exit; 
	include('category_list_data.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!--  AMH 国内领先的云主机面板。 https://amh.sh  -->
<title><?php echo isset($title) ? $title : 'AMH';?></title>
<base href="<?php echo _Http;?>" /> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Language" content="zh-cn">
<link type="text/css" rel="stylesheet" href="View/css/index.css?RANDOM" />
<link type="text/css" rel="stylesheet" href="View/css/buttons.css?RANDOM" />
<script type="text/javascript" src="View/js/jquery.js?RANDOM"></script>
<script type="text/javascript" src="View/js/index.js?RANDOM"></script>
<script type="text/javascript" src="View/js/JJalerts.js?RANDOM"></script>
<script type="text/javascript" src="View/js/amstars.js?RANDOM"></script>
<script type="text/javascript" src="View/js/jquery.poshytip.js?RANDOM"></script>
<link href="View/css/tip/tip-amh.css?RANDOM" rel="stylesheet" type="text/css" />
<link href="View/css/JJalerts.css?RANDOM" rel="stylesheet" type="text/css" />
<link href="View/css/amstars.css?RANDOM" rel="stylesheet" type="text/css" />
<!-- chrome/IE/Firefox/opera/safari -->
<style>
<?php if(strpos($_SERVER['HTTP_USER_AGENT'], 'Opera/') !== false) {?>
.select_text { text-align:left; background: white url(View/images/bg-select.gif) top right no-repeat; }
.select_text .hidden_border { width:70%; margin:0px 0px 0px 5px; display:inline-block; height:25px}
<?php }?>
<?php if($_SESSION['amh_config']['HelpDoc']['config_value'] == 'Off') { ?>
#notice_message {display:none;}
<?php }?>
</style>
<script>
var HTTP_HOST = '<?php echo $_SERVER['HTTP_HOST'];?>';
var amh_token = '<?php echo isset($_SESSION['amh_token']) ? $_SESSION['amh_token'] : '';?>';
var OpenCSRF = '<?php echo isset($_SESSION['amh_config']['OpenCSRF']['config_value'])? $_SESSION['amh_config']['OpenCSRF']['config_value'] : '';?>';
</script>
</head>
<body>
<div id="header_left" style="width:<?php echo (isset($_COOKIE['header_left_open']) && $_COOKIE['header_left_open'] == '1') ? '430' : '28';?>px">
	<div id="header_left_body">
	<div id="user_info">
	<a id="user_avatar" href="javascript:;">
		<img src="/View/images/avatar.png"/>
		<font></font>
	</a>
	<?php if($_SESSION['amh_config']['WebKeyUid']['config_value'] > 0) {?>
	<p id="user_name"><?php echo $_SESSION['amh_config']['WebKeyUsername']['config_value'];?></p>
	<p><font color="<?php echo $_SESSION['amh_config']['UserGroupColor']['config_value'];?>"><?php echo $_SESSION['amh_config']['UserGroup']['config_value'];?></font> - <font color="<?php echo $_SESSION['amh_config']['ServiceGroupColor']['config_value'];?>"><b><?php echo $_SESSION['amh_config']['ServiceGroup']['config_value'];?></b></font>
	<img src="View/images/v<?php echo $_SESSION['amh_config']['ServiceLevel']['config_value'];?>.gif" align="absmiddle" style="margin-top: -1px;"/>
	</p>
	<p style="margin-bottom: 15px;">
	<?php
		$Ktime = $_SESSION['amh_config']['WebKeyTime']['config_value'] - time();
		if($Ktime < 0) {?>
		<font color="red">授权已经过期</font>
	<?php } else {
		$KtimeStr = Functions::CountTime($Ktime);
	?>
		还可用<b><?php echo $KtimeStr[0];?></b><?php echo $KtimeStr[1];?> - <font color="green"><?php echo date('Y-m-d H:i:s', $_SESSION['amh_config']['WebKeyTime']['config_value']);?></font>
	<?php } ?>
	</p>
	<p style="margin:8px;">正版软件 &nbsp;<a href="javascript:;" onclick="pay_key()" class="button" ><span class="clock icon"></span>授权续期</a></p>
	<p style="margin:8px;"><a href="javascript:;" class="button" onclick="logout_key();"><span class="rightarrow icon"></span>退出授权账号</a></p>
	<?php } else { ?>
		<p>&nbsp;</p>
		<p>amh 5.3 免授权版</p>
		<p>无需登录 amh 账号</p>
	<?php } ?>
	</div>
	<div id="love_list">
	<div id="love_list_body"></div>
	<div id="love_list_notice"><img src="View/images/load.gif" /></div>
	</div>
	<div id="user_bottom">
	<p>数据同步 <a href="javascript:;" onclick="up_cache(0)" >更新缓存数据</a> </p>
	<?php 
	$url = "{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
	if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
		$url = str_replace(":{$_SESSION['amh_config']['AMHListens']['config_value']}", ":{$_SESSION['amh_config']['AMHListen']['config_value']}", $url);
	?>
		<p><img src="View/images/https.gif" align="absbottom"> 普通传输协议 <a href="http://<?php echo $url;?>"  >使用HTTP</a> </p>
	<?php } else {
		$url = str_replace(":{$_SESSION['amh_config']['AMHListen']['config_value']}", ":{$_SESSION['amh_config']['AMHListens']['config_value']}", $url);
	?>
		<p><img src="View/images/http.gif" align="absbottom"> 加密安全协议 <a href="https://<?php echo $url;?>"  >使用HTTPS</a> </p>
	<?php } ?>
	</div>
	</div>
	<a id="header_left_open_copy" href="javascript:;">
	</a>
	<a id="header_left_open" href="javascript:;">
		<font id="header_left_open_span"><?php echo (isset($_COOKIE['header_left_open']) && $_COOKIE['header_left_open'] == '1') ? '&lt;' : '';?></font>
	</a>
</div>
<div id="header_main_block"></div>
<?php
	include('header_main.php');
?>
<script>
var active_menu = false;
<?php if(isset($_GET['c'])) {?>
active_menu = '<?php echo $_GET['c'];?>_menu';
<?php } ?>
<?php if(isset($_GET['ModuleSort'])) {?>
active_menu = '<?php echo $_GET['ModuleSort'];?>_menu';
<?php } ?>
active_menu_obj = active_menu ? G(active_menu) : G('index_menu');
active_menu_obj.className += ' active';
</script>
<?php
$tr_i = 0;
?>