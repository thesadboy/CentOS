<?php include('header.php'); ?>
<div id="body">
<h2>AMH <span>»</span> 面板配置</h2>

<?php
	if (!empty($notice)) echo '<div style="margin:5px 2px;width:500px;"><p id="' . $status . '">' . $notice . '</p></div>';
?>
<form action="" method="POST"  id="account">
<table border="0" cellspacing="0"  class="STable" style="width:720px;">
	<tr class="th_tr">
	<th> &nbsp; </th>
	<th>值</th>
	<th>更新时间 / 说明</th>
	</tr>
	<tr class="row"><td>设置面板HTTP端口
	</td>
	<td>
	<input type="text" name="AMHListen" class="input_text" value="<?php echo $amh_config['AMHListen']['config_value'];?>" />
	<input type="hidden" name="AMHListen_old"  value="<?php echo $amh_config['AMHListen']['config_value'];?>" />
	</td>
	<td><?php echo $amh_config['AMHListen']['config_time'];?>
	<div class="dtxt">(避免端口占用 请设置大于<b>8500</b> 小于<b>61000</b>)</div>
	</td>
	</tr>

	<tr class=""><td>设置面板HTTPS端口
	</td>
	<td>
	<input type="text" name="AMHListens" class="input_text" value="<?php echo $amh_config['AMHListens']['config_value'];?>" />
	<input type="hidden" name="AMHListens_old"  value="<?php echo $amh_config['AMHListens']['config_value'];?>" />
	</td>
	<td><?php echo $amh_config['AMHListen']['config_time'];?>
	<div class="dtxt">(使用https加密连接访问面板)</div>
	</td>
	</tr>

	<tr class="row"><td>登录出错次数限制 </td>
	<td><input type="text" name="LoginErrorLimit" class="input_text" value="<?php echo $amh_config['LoginErrorLimit']['config_value'];?>" />
	<input type="hidden" name="LoginErrorLimit_old"  value="<?php echo $amh_config['LoginErrorLimit']['config_value'];?>" />
	</td>
	<td><?php echo $amh_config['LoginErrorLimit']['config_time'];?> </td>
	</tr>

	<tr ><td>设置模块菜单列数 </td>
	<td><input type="text" name="ModuleMenuRow" class="input_text" value="<?php echo $amh_config['ModuleMenuRow']['config_value'];?>" />
	<input type="hidden" name="ModuleMenuRow_old"  value="<?php echo $amh_config['ModuleMenuRow']['config_value'];?>" />
	</td>
	<td><?php echo $amh_config['ModuleMenuRow']['config_time'];?> </td>
	</tr>

	<tr class="row"><td>是否开启自定义菜单 </td>
	<td>
	<input type="checkbox" name="OpenUserMenu" <?php echo ($amh_config['OpenUserMenu']['config_value'] == 'On' ) ? 'checked=""' : '';?> />
	<input type="hidden" name="OpenUserMenu_old"  value="<?php echo $amh_config['OpenUserMenu']['config_value'];?>" />
	</td>
	<td><?php echo $amh_config['OpenUserMenu']['config_time'];?> </td>
	</tr>

	<tr ><td>是否开启CSRF防范 </td>
	<td>
	<input type="checkbox" name="OpenCSRF" <?php echo ($amh_config['OpenCSRF']['config_value'] == 'On' ) ? 'checked=""' : '';?> />
	<input type="hidden" name="OpenCSRF_old"  value="<?php echo $amh_config['OpenCSRF']['config_value'];?>" />
	</td>
	<td><?php echo $amh_config['OpenCSRF']['config_time'];?> 
	<div class="dtxt">(有效防范外部非法请求面板)</div>
	</td>
	</tr>

	<tr class="row"><td>登录是否开启验证码 </td>
	<td>
	<input type="checkbox" name="VerifyCode" <?php echo ($amh_config['VerifyCode']['config_value'] == 'On' ) ? 'checked=""' : '';?> />
	<input type="hidden" name="VerifyCode_old"  value="<?php echo $amh_config['VerifyCode']['config_value'];?>" />
	</td>
	<td><?php echo $amh_config['VerifyCode']['config_time'];?> </td>
	</tr>

	<tr ><td>是否显示版块说明 </td>
	<td>
	<input type="checkbox" name="HelpDoc" <?php echo ($amh_config['HelpDoc']['config_value'] == 'On' ) ? 'checked=""' : '';?> />
	<input type="hidden" name="HelpDoc_old"  value="<?php echo $amh_config['HelpDoc']['config_value'];?>" />
	</td>
	<td><?php echo $amh_config['HelpDoc']['config_time'];?> </td>
	</tr>

	<tr class="row"><td>面板数据私有保护 </td>
	<td>
	<?php echo ($amh_config['DataPrivate']['config_value'] == 'On' ? '已开启' : '未开启');?> 
	</td>
	<td><?php echo $amh_config['DataPrivate']['config_time'];?> 
	<div class="dtxt">( 数据库amh » amh_config » DataPrivate <br />有效值 On/Off，更改后重新登录生效。)</div>
	</td>
	</tr>
	</table>
<button type="submit" class="primary_max button" name="submit">保存</button> 
</form>

</div>
<?php include('footer.php'); ?>